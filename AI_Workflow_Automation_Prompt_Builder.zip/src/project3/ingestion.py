from pathlib import Path
import pandas as pd
def load_csv(path: str):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(p)
