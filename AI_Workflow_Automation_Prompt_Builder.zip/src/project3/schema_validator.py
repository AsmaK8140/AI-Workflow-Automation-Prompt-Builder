from pydantic import BaseModel, ValidationError, validator
from typing import List, Dict, Any
class Task(BaseModel):
    step: int
    description: str
class Workflow(BaseModel):
    workflow_id: str
    user_input: str
    tasks: List[Task]
    tools: List[str]
    prompts: List[str]
def validate(workflow: dict) -> Workflow:
    return Workflow(**workflow)
