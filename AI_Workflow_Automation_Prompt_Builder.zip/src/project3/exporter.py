import json
from pathlib import Path
def export_json(obj: dict, path: str = 'outputs/workflow.json'):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2))
    return str(p)
