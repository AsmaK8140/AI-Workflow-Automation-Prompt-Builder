# Simple rule-based classifier to categorize workflow type
def classify(text: str) -> str:
    t = text.lower()
    if 'email' in t: return 'email'
    if 'backup' in t or 's3' in t or 'drive' in t: return 'backup'
    if 'report' in t or 'dashboard' in t: return 'report'
    if 'alert' in t or 'notify' in t or 'slack' in t: return 'alert'
    if 'etl' in t or 'pipeline' in t: return 'etl'
    return 'general'
