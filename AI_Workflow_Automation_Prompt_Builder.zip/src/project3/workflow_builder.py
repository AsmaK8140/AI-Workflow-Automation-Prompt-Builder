import uuid
from .classifier import classify
from .prompt_templates import summary_prompt, tasks_prompt, tools_prompt
def build_workflow(text: str) -> dict:
    wid = str(uuid.uuid4())
    wtype = classify(text)
    # simple task breakdown heuristic
    prompts = [summary_prompt(text), tasks_prompt(text), tools_prompt(text)]
    tasks = [
        {"step": 1, "description": "Parse and validate input"},
        {"step": 2, "description": f"Classify workflow type: {wtype}"},
        {"step": 3, "description": "Generate detailed task steps using LLM prompts"},
        {"step": 4, "description": "Map tools and produce execution snippets"},
        {"step": 5, "description": "Export workflow JSON and markdown"}
    ]
    tools = ["Email", "Scheduler", "Python script"] if wtype=='email' else ["Scheduler","Storage","Python script"]
    return {
        "workflow_id": wid,
        "user_input": text,
        "type": wtype,
        "tasks": tasks,
        "tools": tools,
        "prompts": prompts
    }
