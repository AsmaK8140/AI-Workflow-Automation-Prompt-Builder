def summary_prompt(text: str) -> str:
    return f"You are a workflow automation expert. Summarize the following request in 3 lines:\n{text}\n"
def tasks_prompt(text: str) -> str:
    return f"Break down this request into step-by-step automation tasks:\n{text}\n"
def tools_prompt(text: str) -> str:
    return f"List suitable tools and brief reasons to automate this:\n{text}\n"
