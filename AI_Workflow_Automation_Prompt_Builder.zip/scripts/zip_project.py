import zipfile, os
root = os.path.dirname(os.path.dirname(__file__))
zipf = os.path.join(root, 'AI_Workflow_Automation_Prompt_Builder.zip')
with zipfile.ZipFile(zipf, 'w') as z:
    for dirname, _, files in os.walk(root):
        for f in files:
            z.write(os.path.join(dirname, f), os.path.relpath(os.path.join(dirname, f), root))
print('ZIP created at', zipf)
