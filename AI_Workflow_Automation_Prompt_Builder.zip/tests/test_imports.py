def test_imports():
    import src.project3.workflow_builder as wb
    assert hasattr(wb, 'build_workflow')
