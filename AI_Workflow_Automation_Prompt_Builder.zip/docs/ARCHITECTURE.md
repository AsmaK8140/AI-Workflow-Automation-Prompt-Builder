# Architecture

See README for high level architecture.