import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))
import streamlit as st
import pandas as pd
import json
from src.project3.workflow_builder import build_workflow
from src.project3.exporter import export_json
st.set_page_config(page_title='AI Workflow Automation Prompt Builder', layout='wide')
st.title('AI Workflow Automation Prompt Builder — Pro')
with st.sidebar:
    st.header('Input')
    uploaded = st.file_uploader('Upload CSV (optional)', type=['csv'])
    user_text = st.text_area('Enter workflow request here', height=120)
    if uploaded is not None:
        df = pd.read_csv(uploaded)
    else:
        df = pd.read_csv('../data/sample_workflows.csv')
st.subheader('Sample Data (first 5 rows)')
st.dataframe(df.head(5))
if st.button('Generate Workflow from Text') and user_text.strip():
    wf = build_workflow(user_text.strip())
    out = export_json(wf)
    st.success(f'Workflow generated and saved to {out}')
    st.subheader('Workflow JSON')
    st.json(wf)
report = Path('../outputs/workflow.json')
if report.exists():
    st.subheader('Latest Saved Workflow')
    st.json(json.loads(report.read_text()))
